# adBlocker

## Detailed Description
Tired of all those boring web ads adverts?

Get rid of them with this simple adBlocker and get back control of your browsing experience.

We remove the ads so that you can browse seemlesly without hindering your web experience.

> The ad guys you are blocking are just looking to make money. so support them from time to time.
